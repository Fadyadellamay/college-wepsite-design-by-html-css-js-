document.addEventListener("scroll", function(){
   if(document.documentElement.scrollTop > 0 ){
        document.querySelector("nav").classList.add("active");

    }else{
        document.querySelector("nav").classList.remove("active");

    }
}); 